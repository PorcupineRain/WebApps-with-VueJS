Vue.createApp({
  data() {
    return {
      count: 0,
    };
  },
}).mount("#app");
